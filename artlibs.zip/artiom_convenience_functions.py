import sys, os, glob
import random
import time

import cv2
import numpy as np
import matplotlib.pyplot as plt
from IPython.display import display, clear_output
import pylab as pl
from tqdm.notebook import tqdm

from fit_image import fit_img_center


import os

def smart_file_finder(file_name, start_path="."):
    if os.path.exists(file_name): return file_name
    file_name = glob.glob(os.path.join(start_path, "**", "*" + file_name), recursive=True)[: 1]
    if file_name:
        print(f"That's what I found: {file_name}")
        return file_name[0]
    else:
        print(f"Sorry, haven't found anything like this ({file_name})")


def show(a, BGR=None, *args, state={"BGR": False}, **kwargs, ):

    if BGR is not None:
        state["BGR"] = BGR
        
    if state["BGR"]:
        a = RGB(a)
        
    plt.figure(figsize=(24, 12))
    try:
        
        plt.imshow(a, *args, **kwargs)
    except:
        plt.imshow(a.astype("uint8"), *args, **kwargs)
        
    plt.show()

s = show


def RGB_to_BGR(a):
    return  cv2.cvtColor(a, cv2.COLOR_RGB2BGR)

def BGR_to_RGB(a):
    return cv2.cvtColor(a, cv2.COLOR_BGR2RGB)


def resize(img, height=None, width=None, **kwargs):
    if height is not None and width is not None:
        return cv2.resize(img, (width, height), **kwargs)
    
    w_over_h = img.shape[1] / img.shape[0]
    
    if height is None and width is not None:
        height = round(width / w_over_h)
        
    elif height is not None and width is None:
        width = round(height * w_over_h)
    
    if height is None and width is None:
        raise Exception
    
    
    return cv2.resize(img, (width, height), **kwargs)

RGB = RGB_to_BGR
BGR = BGR_to_RGB


def half_the_size(img, *args, **kwargs):
    return cv2.resize(img, (img.shape[1] // 2, img.shape[0] // 2), *args, **kwargs)

def downsize(img, r=10, interpolation=cv2.INTER_NEAREST_EXACT, *args, **kwargs):
    if r < 1:
        r = 1 / r
        
    return cv2.resize(img, (img.shape[1] // r, img.shape[0] // r), *args, **kwargs)